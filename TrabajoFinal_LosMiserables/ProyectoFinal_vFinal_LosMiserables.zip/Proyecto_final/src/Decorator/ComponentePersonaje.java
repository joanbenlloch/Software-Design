package Decorator;

public interface ComponentePersonaje {
	void verAtaque();
	void verDefensa();
	void verVida();
	void verEvasion();
	
/*
	int getAtaque();
	int getDefensa();
	int getEvasion();
	*/
}
