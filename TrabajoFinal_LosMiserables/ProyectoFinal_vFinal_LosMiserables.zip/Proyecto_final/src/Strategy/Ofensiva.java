package Strategy;

public class Ofensiva implements Gestor_Strategy{
	public char MetodoEstrategia()
	{
		return 'O';
	}
}
