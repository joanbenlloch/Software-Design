package Main;

import Facade.GameController;

public class Main {

	public static void main(String[] args) {
		
		GameController controladorJuego = new GameController();
		controladorJuego.start();

	}

}
