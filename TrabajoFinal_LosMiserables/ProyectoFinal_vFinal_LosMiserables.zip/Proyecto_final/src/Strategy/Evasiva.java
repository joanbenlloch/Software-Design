package Strategy;

public class Evasiva implements Gestor_Strategy{
	public char MetodoEstrategia()
	{
		return 'E';
	}
}
