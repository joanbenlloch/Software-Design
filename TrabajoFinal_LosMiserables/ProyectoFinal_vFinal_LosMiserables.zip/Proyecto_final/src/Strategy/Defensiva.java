package Strategy;

public class Defensiva implements Gestor_Strategy{
	public char MetodoEstrategia()
	{
		return 'D';
	}
}
