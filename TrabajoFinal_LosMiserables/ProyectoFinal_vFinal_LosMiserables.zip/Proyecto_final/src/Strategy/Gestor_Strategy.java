package Strategy;

public interface Gestor_Strategy {
	public char MetodoEstrategia();
}
